<?php

$conexion=mysqli_connect("localhost","ciam","proyecto22","usuarios")or die(
    "error de conexion");
?>
