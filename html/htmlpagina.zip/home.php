


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
</head>
<body>
<h1>SISTEMA DOMOTICO</h1>
<h2>Universidad tecnica de Ambato</h2>
<h3>Facultad de Ingeniería en Sistemas, Electrónica e Industrial</h3>
<h3>Carrera de Ingeniería en Electrónica y Comunicaciones</h3>
    
</body>
</html>
